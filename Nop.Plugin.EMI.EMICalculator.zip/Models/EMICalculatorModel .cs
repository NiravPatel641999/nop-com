﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocumentFormat.OpenXml.Wordprocessing;
using FluentMigrator.Infrastructure;

namespace Nop.Plugin.EMI.EMICalculator.Models
{
    public class EMICalculatorModel
    {
        [Display(Name = "Loan Amount:")]
        [Required(ErrorMessage = "Loan amount is required.")]
        public decimal LoanAmount { get; set; }

        [Display(Name = "Interest Rate:")]
        [Required(ErrorMessage = "Interest rate is required.")]
        public decimal InterestRate { get; set; }

        [Display(Name = "Loan Term:")]
        [Required(ErrorMessage = "Loan term is required.")]
        public int LoanTerm { get; set; }

        [Display(Name = "Monthly Payment")]
        public decimal MonthlyPayment { get; set; }

        [Display(Name = "Total Payment")]
        public decimal TotalPayment { get; set; }

        [Display(Name = "Total Interest")]
        public decimal TotalInterest { get; set; }
    }
}
