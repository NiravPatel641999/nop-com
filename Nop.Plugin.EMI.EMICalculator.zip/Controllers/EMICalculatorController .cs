﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.EMI.EMICalculator.Models;

namespace Nop.Plugin.EMI.EMICalculator.Controllers
{
    public class EMICalculatorController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(EMICalculatorModel model)
        {
            if (ModelState.IsValid && (model.LoanTerm>0))
            {
                // Calculate EMI
                var loanAmount = model.LoanAmount;
                var interestRate = model.InterestRate / 1200;
                var loanTermMonths = model.LoanTerm * 12;

                var emi = (loanAmount * interestRate * (decimal)Math.Pow(1 + (double)interestRate, loanTermMonths)) /
                          ((decimal)Math.Pow(1 + (double)interestRate, loanTermMonths) - 1);

                model.MonthlyPayment = Math.Round(emi, 2);
                model.TotalPayment = Math.Round(emi * loanTermMonths, 2);
                model.TotalInterest = Math.Round((emi * loanTermMonths) - loanAmount, 2);

                return View(model);
            }

            return View(model);
        }
    }
}
