﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Routing;
using Nop.Services.Plugins;

namespace Nop.Plugin.EMI.EMICalculator
{
    public class EMICalculatorPlugin : BasePlugin, IPlugin
    {
        public override async Task InstallAsync()
        {
            await base.InstallAsync();
        }

        public override async Task UninstallAsync()
        {
            await base.UninstallAsync();
        }

        public void GetConfigurationRoute(out RouteValueDictionary routeValues)
        {
            routeValues = new RouteValueDictionary
            {
                { "controller", "EMICalculator" },
                { "action", "Index" },
                { "area", null }
            };
        }
    }
}
